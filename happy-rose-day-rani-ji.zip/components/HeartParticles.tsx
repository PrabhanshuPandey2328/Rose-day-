
import React, { useMemo } from 'react';

const HeartParticles: React.FC = () => {
  const hearts = useMemo(() => {
    return Array.from({ length: 40 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 8}s`,
      duration: `${8 + Math.random() * 12}s`,
      size: `${1 + Math.random() * 1.5}rem`,
      // White and Red hearts as requested
      color: Math.random() > 0.5 ? 'text-white' : 'text-red-500',
      type: Math.random() > 0.5 ? '❤' : '♥'
    }));
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
      {hearts.map((h) => (
        <div
          key={h.id}
          className={`absolute bottom-[-5rem] heart-float ${h.color} select-none opacity-0`}
          style={{
            left: h.left,
            fontSize: h.size,
            '--duration': h.duration,
            animationDelay: h.delay,
          } as any}
        >
          {h.type}
        </div>
      ))}
      <style>{`
        @keyframes float-heart {
            0% { transform: translateY(0) scale(1); opacity: 0; }
            10% { opacity: 0.6; }
            90% { opacity: 0.6; }
            100% { transform: translateY(-110vh) scale(1.5); opacity: 0; }
        }
        .heart-float {
            animation: float-heart var(--duration) linear infinite;
        }
      `}</style>
    </div>
  );
};

export default HeartParticles;


import React from 'react';

const RoseAnimation: React.FC = () => {
  return (
    <div className="relative w-64 h-96 flex flex-col items-center">
      {/* Rose Head */}
      <div className="relative w-40 h-40">
        {/* Core Petals */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-12 bg-red-900 rounded-full z-40 animate-bloom-1" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-16 bg-red-800 rounded-full z-30 animate-bloom-2" />
        
        {/* Outer Petals */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-24 bg-red-700 rounded-full z-20 animate-bloom-3" style={{ transform: 'translate(-50%, -50%) rotate(45deg)' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-24 bg-red-700 rounded-full z-20 animate-bloom-3" style={{ transform: 'translate(-50%, -50%) rotate(-45deg)' }} />
        
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-32 bg-rose-600 rounded-[50%_50%_10%_10%] z-10 animate-bloom-4" style={{ transform: 'translate(-50%, -50%) rotate(20deg)' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-28 h-32 bg-rose-600 rounded-[50%_50%_10%_10%] z-10 animate-bloom-4" style={{ transform: 'translate(-50%, -50%) rotate(-20deg)' }} />
        
        {/* Widest base petals */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-36 h-36 bg-red-500 rounded-full z-0 animate-bloom-5 opacity-80" />
      </div>

      {/* Stem */}
      <div className="relative flex flex-col items-center h-full">
        <div className="w-2 bg-green-800 h-0 animate-stem-grow rounded-full shadow-lg" />
        
        {/* Leaf Left */}
        <div className="absolute left-[-40px] top-[100px] w-16 h-8 bg-green-700 rounded-[0_100%_0_100%] rotate-[-30deg] opacity-0 animate-leaf-in" style={{ animationDelay: '2.5s' }} />
        
        {/* Leaf Right */}
        <div className="absolute right-[-40px] top-[160px] w-16 h-8 bg-green-700 rounded-[100%_0_100%_0] rotate-[30deg] opacity-0 animate-leaf-in" style={{ animationDelay: '3.0s' }} />
      </div>

      <style>{`
        @keyframes bloom-1 { from { transform: translate(-50%, -50%) scale(0); } to { transform: translate(-50%, -50%) scale(1); } }
        @keyframes bloom-2 { from { transform: translate(-50%, -50%) scale(0); } to { transform: translate(-50%, -50%) scale(1.1); } }
        @keyframes bloom-3 { from { transform: translate(-50%, -50%) scale(0); } to { transform: translate(-50%, -50%) scale(1.2); } }
        @keyframes bloom-4 { from { transform: translate(-50%, -50%) scale(0); } to { transform: translate(-50%, -50%) scale(1.3); } }
        @keyframes bloom-5 { from { transform: translate(-50%, -50%) scale(0); } to { transform: translate(-50%, -50%) scale(1.4); } }
        
        .animate-bloom-1 { animation: bloom-1 2s ease-out forwards 0.5s; transform: scale(0); }
        .animate-bloom-2 { animation: bloom-2 2.2s ease-out forwards 0.8s; transform: scale(0); }
        .animate-bloom-3 { animation: bloom-3 2.5s ease-out forwards 1.2s; transform: scale(0); }
        .animate-bloom-4 { animation: bloom-4 2.8s ease-out forwards 1.5s; transform: scale(0); }
        .animate-bloom-5 { animation: bloom-5 3.0s ease-out forwards 1.8s; transform: scale(0); }
        
        @keyframes stem-grow { from { height: 0; } to { height: 250px; } }
        .animate-stem-grow { animation: stem-grow 2s ease-out forwards; }
        
        @keyframes leaf-in { from { opacity: 0; transform: scale(0); } to { opacity: 1; transform: scale(1); } }
        .animate-leaf-in { animation: leaf-in 1s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default RoseAnimation;

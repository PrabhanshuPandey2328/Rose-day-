
import React, { useState } from 'react';

interface QuestionPageProps {
  question: string;
  placeholder: string;
  validate: (answer: string) => boolean;
  onSuccess: () => void;
}

const QuestionPage: React.FC<QuestionPageProps> = ({ question, placeholder, validate, onSuccess }) => {
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate(answer)) {
      onSuccess();
    } else {
      setError(true);
      setAnswer('');
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-rose-50 p-4 transition-all duration-500">
      <div className="bg-white p-10 rounded-3xl shadow-2xl text-center max-w-md w-full border-t-4 border-pink-400 animate-fade-in">
        <h1 className="text-3xl md:text-4xl font-playfair font-bold text-pink-700 mb-8 leading-relaxed">
          {question}
        </h1>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-6">
          <input
            type="text"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder={placeholder}
            className="w-full px-5 py-4 text-lg border-2 border-pink-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-transparent transition-all bg-rose-50/50"
          />
          
          <button
            type="submit"
            className="w-full py-4 text-xl font-bold bg-pink-500 text-white rounded-xl shadow-lg hover:bg-pink-600 active:scale-95 transition-all"
          >
            Submit 💌
          </button>
        </form>

        <div className={`mt-6 text-rose-500 font-playfair italic h-6 transition-opacity duration-300 ${error ? 'opacity-100' : 'opacity-0'}`}>
          Try again... 🥺
        </div>
      </div>
    </div>
  );
};

export default QuestionPage;

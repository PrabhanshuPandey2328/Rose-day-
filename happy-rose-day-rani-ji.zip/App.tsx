
import React, { useState } from 'react';
import QuestionPage from './components/QuestionPage';
import RosePage from './components/RosePage';
import SongReveal from './components/SongReveal';

type AppState = 'FLOWER' | 'DRAMA' | 'READY' | 'ROSE_CELEBRATION' | 'SONG_REVEAL';

const App: React.FC = () => {
  const [step, setStep] = useState<AppState>('FLOWER');

  return (
    <div className="w-full h-screen overflow-hidden font-playfair">
      {step === 'FLOWER' && (
        <QuestionPage 
          question="Which Flower do you love? 🌸" 
          placeholder="Your answer..."
          validate={(ans) => ans.toLowerCase().trim() === 'rose'}
          onSuccess={() => setStep('DRAMA')}
        />
      )}
      
      {step === 'DRAMA' && (
        <QuestionPage 
          question="Do you like my dramaaa?" 
          placeholder="Answer honestly... 😉"
          validate={(ans) => ans.toLowerCase().replace(/\s+/g, '') === 'iloveit'}
          onSuccess={() => setStep('READY')}
        />
      )}

      {step === 'READY' && (
        <div className="flex flex-col items-center justify-center min-h-screen bg-rose-100 p-6 text-center">
          <div className="bg-white p-10 rounded-3xl shadow-2xl max-w-md w-full border-b-8 border-pink-400 animate-fade-in">
            <h2 className="text-3xl font-bold text-pink-700 mb-6">
              Since you answered it honestly, I have a surprise for you! Are you ready?
            </h2>
            <button
              onClick={() => setStep('ROSE_CELEBRATION')}
              className="text-6xl hover:scale-125 transition-transform duration-300 active:scale-95"
            >
              🥳
            </button>
          </div>
        </div>
      )}

      {step === 'ROSE_CELEBRATION' && (
        <RosePage onShowSong={() => setStep('SONG_REVEAL')} />
      )}

      {step === 'SONG_REVEAL' && (
        <SongReveal />
      )}
    </div>
  );
};

export default App;


import React, { useState, useEffect } from 'react';
import RoseAnimation from './RoseAnimation';
import HeartParticles from './HeartParticles';

interface RosePageProps {
  onShowSong: () => void;
}

const RosePage: React.FC<RosePageProps> = ({ onShowSong }) => {
  const [showPrompt, setShowPrompt] = useState(false);
  const [persuade, setPersuade] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowPrompt(true);
    }, 10000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full h-screen bg-gradient-to-br from-rose-600 to-red-900 flex flex-col items-center justify-center overflow-hidden">
      <HeartParticles />

      {/* The Rose Container */}
      <div className="relative z-10 w-full max-w-md flex flex-col items-center mb-16">
        <RoseAnimation />
      </div>

      {/* Greeting Message - Positioned at bottom */}
      <div className="absolute bottom-16 z-20 text-center animate-fade-in-delayed">
        <h2 className="font-sacramento text-5xl md:text-7xl text-white drop-shadow-lg">
          Happy Rose Dayyy
        </h2>
        <p className="font-sacramento text-3xl md:text-5xl text-white mt-2 drop-shadow-md">
          
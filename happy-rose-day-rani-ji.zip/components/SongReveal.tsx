
import React from 'react';

const SongReveal: React.FC = () => {
  return (
    <div className="relative w-full h-screen bg-[#2c1313] flex flex-col items-center justify-center p-4">
      {/* Spotify Player Mockup based on the image provided */}
      <div className="relative w-full max-w-lg bg-[#3d1a1a] rounded-[2rem] overflow-hidden shadow-2xl flex flex-col">
        {/* Background Image Effect */}
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <img 
            src="https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&q=80&w=800" 
            alt="Fitoor Background"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="relative p-8 z-10 flex flex-col">
          {/* Header */}
          <div className="flex items-center gap-2 mb-8">
            <svg className="w-6 h-6 text-[#1DB954]" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.494 17.306c-.216.353-.671.464-1.024.248-2.859-1.747-6.458-2.143-10.702-1.171-.403.093-.812-.162-.905-.565-.093-.403.162-.812.565-.905 4.643-1.062 8.625-.61 11.818 1.34.353.216.464.671.248 1.024zm1.465-3.264c-.271.44-.848.58-1.288.309-3.273-2.012-8.261-2.595-12.13-1.419-.496.15-.1.884-.241.884-.496 0-.884-.4-.884-.884 4.417-1.34 9.912-.686 13.684 1.63.44.271.58.848.309 1.288zm.139-3.414c-3.924-2.33-10.392-2.546-14.155-1.404-.602.183-1.238-.162-1.421-.764-.183-.602.162-1.238.764-1.421 4.316-1.311 11.455-1.054 15.968 1.623.541.321.718 1.021.397 1.562-.321.541-1.021.718-1.562.397z"/>
            </svg>
            <span className="text-gray-300 text-sm font-bold tracking-wider">Spotify • Hindi stuff</span>
          </div>

          {/* Song Info */}
          <div className="mb-10">
            <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">Yeh Fitoor Mera</h1>
            <p className="text-2xl text-rose-200 opacity-80">Arijit Singh</p>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between mb-8 px-4">
            <div className="bg-[#b38c8c] rounded-full p-2">
              <svg className="w-6 h-6 text-[#2c1313]" fill="currentColor" viewBox="0 0 24 24">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
              </svg>
            </div>
            <div className="flex items-center gap-8">
              <svg className="w-8 h-8 text-[#f7d5d5]" fill="currentColor" viewBox="0 0 24 24"><path d="M6 6h2v12H6zm3.5 6L18 6v12z"/></svg>
              <div className="bg-[#f7d5d5] rounded-full p-4">
                <svg className="w-10 h-10 text-[#2c1313]" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
              </div>
              <svg className="w-8 h-8 text-[#f7d5d5]" fill="currentColor" viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
            </div>
            <div className="w-8 h-8" /> {/* Placeholder for alignment */}
          </div>

          {/* Progress Bar */}
          <div className="px-2">
            <div className="h-1.5 w-full bg-[#5e3b3b] rounded-full overflow-hidden mb-2">
              <div className="h-full w-1/4 bg-[#f7d5d5] rounded-full" />
            </div>
            <div className="flex justify-between text-xs text-rose-200 opacity-60 font-bold">
              <span>00:40</span>
              <span>04:43</span>
            </div>
          </div>
        </div>

        {/* Right Side Image (Katrina/Aditya fitoor vibe) */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 z-0 opacity-40">
           <img 
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400" 
            alt="Song Art" 
            className="h-full w-full object-cover"
           />
           <div className="absolute inset-0 bg-gradient-to-r from-[#3d1a1a] to-transparent" />
        </div>
      </div>

      <div className="mt-12 text-center text-rose-100 font-sacramento text-4xl animate-pulse">
        This song always reminds me of you... 💖
      </div>
    </div>
  );
};

export default SongReveal;
